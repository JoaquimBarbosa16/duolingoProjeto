# Duolingo Layout Clone — Android Studio

Projeto acadêmico para a atividade **“Clonando o Layout de um App Famoso”**.

## Tela escolhida

Foi reproduzida uma única tela de referência: **“Translate this sentence”**, baseada no print fornecido para a atividade.

### Elementos reproduzidos

- Barra superior com configurações, progresso, vidas e infinito
- Título da atividade
- Personagem em `ImageView`
- Balão de fala
- 7 opções de palavras
- Área de resposta
- Indicador de resposta correta
- Botões de compartilhar e reportar
- Botão `CONTINUE`
- Organização principal feita com `ConstraintLayout`

## Como abrir

1. Extraia o arquivo ZIP.
2. Abra a pasta `DuolingoLayoutClone` no Android Studio.
3. Aguarde o Gradle Sync terminar.
4. Execute em um emulador ou celular Android.

## Observação

O objetivo do projeto é a reprodução visual da tela para fins acadêmicos. O botão `CONTINUE` possui apenas uma ação simples de demonstração e não implementa o aplicativo original.

## Arquivos importantes

- `app/src/main/res/layout/activity_main.xml` — layout da tela
- `app/src/main/java/com/example/duolingolayoutclone/MainActivity.java` — Activity
- `app/src/main/res/drawable/` — fundos e ícones
- `app/src/main/res/drawable/character.png` — personagem ilustrado usado na versão final
- `referencia.png` — imagem de referência fornecida para a atividade
